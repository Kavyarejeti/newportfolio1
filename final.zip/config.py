MAIL_SERVER = 'smtp.gmail.com'
MAIL_PORT = 587
MAIL_USE_TLS = True
MAIL_USERNAME = 'your_email@gmail.com'       # replace with your Gmail
MAIL_PASSWORD = 'your_app_password'          # generate from https://myaccount.google.com/apppasswords
